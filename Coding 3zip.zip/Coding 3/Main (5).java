// You are using Java
import java.util.*;
class Main {
public static boolean ispalindrome(String str) {
for(int i=0;i<str.length();i++) {
int n = str.length();
    if(str.charAt(i)!=str.charAt(n-i-1)) {
        return false;
    }
}
return true;
}
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
String str = sc.nextLine();
String s[]= str.split("[\\s]+");
int count = 0;
for(int i=0;i<s.length;i++) {
    if(ispalindrome(s[i])) {
    count++;}
}

System.out.println(count);
}
}



