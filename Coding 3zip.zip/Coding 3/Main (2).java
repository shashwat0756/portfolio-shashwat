// You are using Java
import java.util.Scanner;
class practice {
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
int n = sc.nextInt();
int arr[] = new int[n];
for(int i=0;i<arr.length;i++) {
    arr[i] = sc.nextInt();
}
int key = sc.nextInt();

int c=0;
int c1=0;
int c2=0;
for(int i=0;i<arr.length;i++) {
        
        if(arr[i]==key) {
            c++;
        }
        else if(arr[i]<key) {
            c1++;
        }
        else{
            c2++;
        }
    }
    System.out.println(c);
    System.out.println(c1);
    System.out.println(c2);
    
}
}


//     if(arr[i]%2==0) {
//         even_count+=1;
//     }
//     else{
//         odd_count+=1;
//     }
    
// }
// System.out.println(n);
// System.out.println(sum);
// System.out.printf("total avg%.2f\n",(double)sum/n);
// System.out.println(even_count);
// System.out.println(odd_count);
// }
// }
