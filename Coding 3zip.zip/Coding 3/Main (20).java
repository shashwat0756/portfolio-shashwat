// You are using Java
import java.util.*;
interface OrderProcessor {
    abstract void processOrder(int orderId,double price);
}
class OnlineOrder implements OrderProcessor {
    public void processOrder(int orderId,double price) {
        System.out.println("Processing online order with ID: "+orderId+ "and amount: " +price);
        System.out.println("Online order processed successfully!");
    }
}
class InstoreOrder implements OrderProcessor {
    public void processOrder(int orderId,double price) {
        System.out.println("Processing in-store order with ID: "+orderId+ "and amount: "+price);
        System.out.println("In-store order processed successfully!");
    }
}
class Main {
    public static void main(String[]args) {
    OnlineOrder o = new OnlineOrder();
    InstoreOrder it = new InstoreOrder();
    o.processOrder(234,23.76);
    it.processOrder(237,67.98);
    }
}
    
