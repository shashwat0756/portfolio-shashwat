// You are using Java
import java.util.*;
class Employee {
String name;
int id;
int salary;
public Employee() {
}
public Employee(String name,int id,int salary) {
this.name=name;
this.id=id;
this.salary=salary;
}
public String getName() {
return this.name;
}
public int getId() {
return this.id;
}
public int getSalary() {
return this.salary;
}
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
ArrayList<Employee> list = new ArrayList();
int n = Integer.parseInt(sc.nextLine());
for(int i=0;i<n;i++) {
String name = sc.nextLine();
int id = Integer.parseInt(sc.nextLine());
int salary = Integer.parseInt(sc.nextLine());
Employee e = new Employee(name,id,salary);
list.add(e);
}
String nameSearch = sc.nextLine();
String removeSearch = sc.nextLine();
System.out.println("Employee List:");
for(Employee emp:list) {
System.out.println(emp.getName()+ " "+emp.getId()+ " "+emp.getSalary());
}
int index=-1;
for(int i=0;i<n;i++) {
    String name= list.get(i).name;
    if(name.equals(nameSearch)) {
        index = i;
        break;
    }
}
if(index==-1) {
    System.out.println(nameSearch+" is not found");
}
else{
    System.out.println(nameSearch+ "is found at "+index+"position");
}

String remove = sc.nextLine();
Employee toRemove = null;

for (Employee emp : list) {
if (emp.getName().equals(remove)) {
toRemove = emp;
break;
}
}

if (toRemove != null) {
    list.remove(toRemove);
    System.out.println("removed successfully");
        } else {
    System.out.println("Employee not found");
        }

System.out.println("Employee list after deleting:");
for (Employee emp : list) {
System.out.println(emp.getName() + " " + emp.getId() + " " + emp.getSalary());
}
}
}

