// You are using Java
import java.util.Scanner;

class Circle {
    
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
int a = sc.nextInt();
int b = sc.nextInt();
int c = sc.nextInt();
if(a<18||b<18||c<18) {
    System.out.println("Invalid inputs");
}
else {
    if(a>b&&a>c) {
        System.out.println(a);
    }
    else if(b>c&&b>a) {
        System.out.println(b);
    }
    else {
        System.out.println(c);
    }

}
}
}