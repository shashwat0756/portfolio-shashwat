// You are using Java
// You are using Java

import java.util.*;

class Contact {

    String contactName;
    String phoneNumber;
    int age;
    public Contact() {}
    public Contact(String contactName,String phoneNumber,int age){
        this.contactName=contactName;
        this.phoneNumber= phoneNumber;
        this.age=age;
    }
    public void show(){
        System.out.println("Contact Name: " + contactName + ", Phone Number: " + phoneNumber + ", Age: " +age);
    }
}

class ContactMgr {
    Contact[] contacts;
    int count;
    public ContactMgr() {}
    public ContactMgr(int n){
        contacts = new Contact[n];
        count=0;
    }

    public void displayAll(){
        for(int i=0;i<contacts.length;i++){
            contacts[i].show();
        }
    }

    public void addContact(String contactName,String phoneNumber,int age){
        contacts[count] = new Contact(contactName,phoneNumber,age);
        count++;
    }
} 

class Main{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        ContactMgr mgr = new ContactMgr(n);
        for(int i=0;i<n;i++){
            String contactName = sc.nextLine();
            String phoneNumber = sc.nextLine();
            int age = Integer.parseInt(sc.nextLine());
            mgr.addContact(contactName,phoneNumber,age);
        }
        mgr.displayAll();
    }

}    

 