// You are using Java
import java.util.Scanner;
class practice {
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
int n = sc.nextInt();
int arr[] = new int[n];
for(int i=0;i<arr.length;i++) {
    arr[i] = sc.nextInt();
}
int sum = 0;
int even_count=0;
int odd_count = 0;
for(int i=0;i<arr.length;i++) {
    sum = sum + arr[i];
    if(arr[i]%2==0) {
        even_count+=1;
    }
    else{
        odd_count+=1;
    }
    
}
System.out.println(n);
System.out.println(sum);
System.out.printf("total avg%.2f\n",(double)sum/n);
System.out.println(even_count);
System.out.println(odd_count);
}
}
