// You are using Java
import java.util.*;
class Main {
    public static void main(String[]args) {
    Scanner sc = new Scanner(System.in);
    String name = sc.nextLine();
    int age = Integer.parseInt(sc.nextLine());
    double salary = Double.parseDouble(sc.nextLine());
    if(age<0) {
        System.out.println("Age must be a non-negative integer.");
        age=0;
    }
    if(salary<0.0) {
        System.out.println("Salary must be a non-negative double.");
        salary=0.0;
    }
    
    System.out.println("Employee Details:");
    System.out.printf("Name: " +name+ "\n");
    System.out.printf("Age:" +age+ "\n");
    System.out.printf("Salary: " +salary+ "\n");
    
    }
    }
