// You are using Java
import java.util.*;
class Work {
    String name;
    int hours;
    String subject;
    public Work() {
    }
    public Work(String name,int hours,String subject) {
        this.name = name;
        this.hours = hours;
        this.subject = subject;
    }
    public void show() {
        System.out.printf("Task: "+name+ ", "+ "Hours: "+hours+ ", "+ "Subject: " +subject+ "\n");
    }
    public static void main(String[]args) {
    Scanner sc = new Scanner(System.in);
    ArrayList<Work> list = new ArrayList();
    int n = Integer.parseInt(sc.nextLine());
    for(int i=0;i<n;i++) {
        String name = sc.nextLine();
        if(name.equals("done")) {
            break;
        }
        int hours = Integer.parseInt(sc.nextLine());
        String subject = sc.nextLine();
        Work w = new Work(name,hours,subject);
        list.add(w);
    }
    Collections.sort(list, (obj1,obj2)-> Integer.compare(obj1.hours,obj2.hours));
    for(Work ww:list) {
        ww.show();
    }
    }
}