// You are using Java
import java.util.*;
class PriceComparator implements Comparator<Book> {
public int compare(Book obj1,Book obj2) {
    return Double.compare(obj2.price,obj1.price);
}
}
class Book {
    int id;
    String name;
    String author;
    double price;
    public Book() {
    }
    
    public Book(int id,String name,String author,double price) {
        this.id=id;
        this.name=name;
        this.author=author;
        this.price=price;
    }
    public void show() {
        System.out.printf("Id: %d Name: %s Author: %s Price: %.2f\n",id,name,author,price);
    }
    
    public static void main(String[]args) {
    Scanner sc = new Scanner(System.in);
    ArrayList<Book> list = new ArrayList();
    int n = Integer.parseInt(sc.nextLine());
    for(int i=0;i<n;i++) {
        int id = Integer.parseInt(sc.nextLine());
        String name = sc.nextLine();
        String author = sc.nextLine();
        double price = Double.parseDouble(sc.nextLine());
        Book b = new Book(id,name,author,price);
        list.add(b);
    }
    int searchId = Integer.parseInt(sc.nextLine());
    int searchIdd = Integer.parseInt(sc.nextLine());
    Double pricee = Double.parseDouble(sc.nextLine());
    Collections.sort(list,new PriceComparator());
    //Collections.sort(list,(obj1,obj2)-> Double.compare(obj2.price,obj1.price));
    for(Book bb:list) {
        bb.show();
    }
    boolean flag = false;
    for(Book bb:list) {
    if(bb.id==searchId) {
    flag=true;
    break;
          }
          //System.out.printf("Book not found with ID %d\n",searchId);
    }
    System.out.println("Book found");
    if(flag==true) {
        for(Book bb:list) {
        bb.show();
    }
    }
    else{
        System.out.printf("Book not found with ID %d\n",searchId);
    }
           flag = false;
           for(Book bb:list) {
         if(bb.id==searchIdd) {
             bb.price= pricee;
           System.out.println("Book Updated");
           flag = true;
           bb.show();
           break;
         } 
       }
       for(Book bb:list) {
           bb.show();
     }
    }
} 

//     }  
// }

