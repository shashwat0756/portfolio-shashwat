// You are using Java
import java.util.*;
class Hall {
    int id;
    String Name;
    double collection;
    public Hall() {
    }
    public Hall(int id,String Name,double collection) {
    this.id=id;
    this.Name=Name;
    this.collection=collection;
    }
   public static void show() {
       System.out.printf("ID: %d Name: %s collection: %.2f\n");
   }
   public static void main(String[]args) {
   Scanner sc = new Scanner(System.in);
   ArrayList<Hall> list = new ArrayList();
   int n = Integer.parseInt(sc.nextLine());
   for(int i=0;i<n;i++) {
       int id = Integer.parseInt(sc.nextLine());
       String name = sc.nextLine();
       double collection = Double.parseDouble(sc.nextLine());
       Hall h = new Hall(id,name,collection);
       list.add(h);
       }
         int editId = Integer.parseInt(sc.nextLine());
         int removeId = Integer.parseInt(sc.nextLine());
       System.out.println("Hall Details");
       for(Hall hh:list) {
           hh.show();
       }
       int removeId = Integer.parseInt(sc.nextLine());
       for(Hall hh:list) {
           if(hh.id==removeId) {
               list.remove(hh);
               System.out.println("Hall with ID: %d removed successfully",id);
               break;
           }
       }
       System.out.println("Hall with ID: %d not found",id);
       for(Hall hh:list) {
           hh.show();
   }
}
}
   
   