// You are using Java
import java.util.*;
class Student {
    private int studentId;
    private String studentName;
    private int totalScore;
Student() {
}
public Student(int studentId,String studentName,int totalScore) {// parameterized constructor
this.studentId = studentId;
this.studentName = studentName;
this.totalScore = totalScore;
}
public void show() {
    System.out.println(this.studentId);
    System.out.println(this.studentName);   
    System.out.println(this.totalScore);
}
public void setStudentId(int studentId) {    //setter has argument and no return type and getter has return type
    this.studentId=studentId;
}
public void setStudentName(String studentName) {
    this.studentName=studentName;
}
public void setTotalScore(int totalScore) {
    this.totalScore = totalScore;
}
public int getStudentId() {
    return this.studentId;
}
public String getStudentName() {
    return this.studentName;
}
public int getTotalScore() {
    return this.totalScore;
}
}
class Main {
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
int studentId = sc.nextInt(); sc.nextLine();
String studentName = sc.nextLine();
int totalScore = sc.nextInt();
Student student1 = new Student(studentId,studentName,totalScore);
student1.setStudentId(studentId);
student1.setStudentName(studentName);
student1.show();
student1.setTotalScore(totalScore);
student1.show();

}
    
}