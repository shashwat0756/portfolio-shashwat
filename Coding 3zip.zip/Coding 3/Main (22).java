// You are using Java
import java.util.*;
class Task {
    String name;
    int days;
    String priority;
    public Task() {
    }
    public Task(String name,int days,String priority) {
        this.name = name;
        this.days = days;
        this.priority=priority;
    }
    public void show() {
    System.out.printf("Task: "+name+ ", "+ "Deadline: "+days+ " "+  "days " + ", "+ "Priority: "+priority+ "\n");
    }
    public static void main(String[]args) {
    Scanner sc = new Scanner(System.in);
    ArrayList<Task> list = new ArrayList();
    while(true) {
        String name = sc.nextLine();
        if(name.equals("Completed")) {
            break;
        }
        int days = Integer.parseInt(sc.nextLine());
        String priority = sc.nextLine();
        Task tt = new Task(name,days,priority);
        list.add(tt);
    }
    Collections.sort(list,(obj1,obj2)->Integer.compare(obj1.days,obj2.days));
    for(Task t:list) {
        t.show();
    }
    }
}