// You are using Java
import java.util.*;
class practice {
public static void  diagonalsum(int arr[][]) {
int sum1 = 0,sum2=0;
int n = arr.length;
for(int i=0;i<arr.length;i++) {
    for(int j=0;j<arr.length;j++) {
        if(i==j) {
            sum1 = sum1 +  arr[i][j];
        }
        if(i+j==n-1) {
            sum2 = sum2 + arr[i][j];
        }
    }
}
System.out.println(sum1);
System.out.println(sum2);
    
}
public static void main(String[]args) {
int arr[][] = {{12,23,34},{34,11,45},{20,10,40}};
diagonalsum(arr);
}
}
  





