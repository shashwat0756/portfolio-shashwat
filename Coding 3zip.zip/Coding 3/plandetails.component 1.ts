import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { meals } from 'src/meals';
@Component({
  selector: 'app-plandetails',
  templateUrl: './plandetails.component.html',
  styleUrls: ['./plandetails.component.css']
})
export class PlandetailsComponent implements OnInit {

  meals: any[]=meals;
  meal:any;
  id: number=0;

  constructor(private actRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.id=+this.actRoute.snapshot.paramMap.get("id");
    this.getMealById(this.id);
  }
  getMealById(id:number){
    this.meal=this.meals.find(x=>x.id===id);
  }

}
