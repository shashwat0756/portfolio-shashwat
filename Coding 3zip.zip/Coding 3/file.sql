# You are using MYSQL
create table employee(
empId int primary Key,
empName varchar(20),
salary int,
department varchar(20),
location varchar(20),
bonus decimal(10,2)
);
describe employee;  #Structure of table

INSERT INTO employee(empId,empName,salary,department,location,bonus)
Values
(12345,'Sanjay',15000,'IT','Chennai',546.35),
(45678,'Abhishek',12000,'HR','Hyd',123.45),
(45679,'Sneha',11000,'Fin','BANG',123.45),
(98765,'Ravi',14000,'Admin','Chennai',200.00),
(11223,'Rajesh',9000,'Support','Hyd',150.75);

#select * from employee where salary>=1000 and salary<=15000;
#select * from employee order by salary desc;
select empName,Salary,salary*1.05 increased_salary from employee;  #Alias using column

#update employee set bonus = bonus*1.10 where salary<15000;
#update employee set bonus = bonus*1.05 where salary>=15000;
delete from employee where salary between 12000 and 15000 limit 1;
select * from employee;
update employee set salary=salary*1.10 where empName like 'S%';
update employee set salary = salary+5000 where (location='chennai' or location='Hyderabad') and salary <15000;
select * from employee;
