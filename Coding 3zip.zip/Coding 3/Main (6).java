// You are using Java
import java.util.*;
class LL {
public static void main(String[]args) {
String str = "This is my House";
char str2[] = str.toCharArray();
for(int i=0;i<str2.length;i++) {
    if(str2[i]>='A'&& str2[i]<='Z') {
        str2[i] = (char)(str2[i] + 32);
    }
    else if(str2[i]>='a'&& str2[i]<='z') {
        str2[i] = (char)(str2[i] - 32);
        
    }
}
for(int i=0;i<str2.length;i++) {
    System.out.print(str2[i]);
}
}
}