// You are using Java
import java.util.*;
class Product {
    int id;
    String productName;
    double price;
    boolean avail;
    public Product() {
        }
    public Product(int id,String productName,double price) {
        this.id=id;
        this.productName = productName;
        this.price = price;
        this.avail = true;
    }
    public void show() {
        System.out.printf("id=%d | name= %s | price=%.2f | available=%b\n",this.id,this.productName,this.price,this.avail);
    }
    public static void main(String[]args) {
    Scanner sc = new Scanner(System.in);
    int id = 101;
    ArrayList<Product> list = new ArrayList();
    int n = Integer.parseInt(sc.nextLine());
    for(int i=0;i<n;i++) {
        String productName = sc.nextLine();
        double price = Double.parseDouble(sc.nextLine());
        Product p = new Product(id,productName,price);
        list.add(p);
        id++;
    }
    System.out.println("Initial Inventory:");
    for(Product pp:list) {
        pp.show();
    }
    int searchId= Integer.parseInt(sc.nextLine());
    int removeId = Integer.parseInt(sc.nextLine());
    boolean flag = false;
    for(Product pp:list) {
        if(pp.id==searchId) {
            System.out.printf("Product with ID %d is sold\n",searchId);
            pp.show();
            flag = true;
            break;
            }
    }
    for(Product pp:list) {
        if(pp.id==removeId) {
            list.remove(pp);
            System.out.printf("Product with ID %d removed successfully.\n",removeId);
            break;
        }
    }
    System.out.printf("Product Id %d not found\n",removeId);
    for(Product pp:list) {
        pp.show();
    }
    
    
    }
}