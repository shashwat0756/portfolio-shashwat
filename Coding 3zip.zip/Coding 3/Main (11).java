// You are using Java
import java.util.*;
class Main {
    public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
ArrayList<Integer> list = new ArrayList();
while(true) {
    int n = sc.nextInt();
    if(n==0) {
        break;
    }
        list.add(n);
}
System.out.print(list);// to display data in a single statement

}
    
}

    