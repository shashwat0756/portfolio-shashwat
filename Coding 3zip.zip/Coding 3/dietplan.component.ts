import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { meals } from 'src/meals';
@Component({
  selector: 'app-dietplan',
  templateUrl: './dietplan.component.html',
  styleUrls: ['./dietplan.component.css']
})
export class DietplanComponent implements OnInit {

  meals: any[]=meals;

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  viewMealDetails(id:number){
    this.router.navigate(['/plandetail', id], {queryParams: {}});
  }

}
