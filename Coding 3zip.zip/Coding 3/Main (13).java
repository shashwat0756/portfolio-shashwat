// You are using Java
import java.util.*;
class Employee {
String name;
int id;
int salary;
public Employee() {
}
   Employee(String name,int id,int salary) {
this.name=name;
this.id=id;
this.salary=salary;
}

public String getName(){
    return name;
}
public int getId(){
    return id;
}
public int getSalary(){
    return salary;
}
}
class Main {
public static void main(String[]args) {
Scanner sc = new Scanner(System.in);
ArrayList<Employee> list = new ArrayList();
int n =sc.nextInt();
sc.nextLine();
for(int i=0;i<n;i++) {
String name = sc.nextLine();
int id = Integer.parseInt(sc.nextLine());
int salary =Integer.parseInt(sc.nextLine());
Employee e = new Employee(name,id,salary);;
list.add(e);

}
System.out.println("Employee List:");
for(Employee emp:list){
System.out.println(emp.getName()+" "+emp.getId()+" "+emp.getSalary());
}

}
}
